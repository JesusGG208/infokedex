En la carpeta del proyecto, abre una consola de comandos y ponen:
```
python -m venv .venv
```
En WINDOWS:
```
source .venv/Scripts/activate
```
En Linux:
```
source .venv/bin/activate
```

Y pon:
```
pip install django
pip install django-debug-toolbar
pip install pillow
pip install psycopg2
```

Finalmente pon:
```
python manage.py makemigrations
python manage.py migrate
python manage.py runserver
```

Y le saldrá el enlace al servidor local y podrá ver el proyecto en web.
Para acceder al admin, ve este enlace http://127.0.0.1:8000/. 
El nombre y la contraseña del superusuario:
User: admin
Password: admin