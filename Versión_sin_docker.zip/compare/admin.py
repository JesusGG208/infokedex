from django.contrib import admin
from compare.models import Compare

# Register your models here.
admin.site.register(Compare)